import { useState } from 'react';
import { Check, Plus, Trash2 } from 'lucide-react';
import { PRIORITIES, Priority, uid, useDay } from '../../context/DaymarkContext';
import { Card, btn, input } from '../ui';

const DOT: Record<Priority, string> = { Urgent: 'bg-red-500', High: 'bg-orange-500', Medium: 'bg-amber-400', Low: 'bg-slate-400' };

export default function TasksView() {
  const { s, set } = useDay();
  const [title, setTitle] = useState('');
  const [priority, setPriority] = useState<Priority>('Medium');
  const [est, setEst] = useState(30);
  const [delegate, setDelegate] = useState(false);
  const [filter, setFilter] = useState<'open' | 'done' | 'all'>('open');
  const add = () => {
    if (!title.trim()) return;
    set({ tasks: [...s.tasks, { id: uid(), title: title.trim(), priority, done: false, estMin: est, actMin: 0, ...(delegate && s.role === 'CEO' ? { from: 'CEO' as const } : {}) }] });
    setTitle('');
  };
  const shown = s.tasks.filter((t) => filter === 'all' || (filter === 'done') === t.done)
    .sort((a, b) => PRIORITIES.indexOf(a.priority) - PRIORITIES.indexOf(b.priority));
  const upd = (id: string, p: object) => set({ tasks: s.tasks.map((t) => t.id === id ? { ...t, ...p } : t) });
  return (
    <>
      <Card title="Add task">
        <div className="flex gap-2">
          <input className={input} placeholder="Task title" value={title} onChange={(e) => setTitle(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && add()} />
          <button aria-label="Add task" className={btn} onClick={add}><Plus size={18} /></button>
        </div>
        <div className="mt-2 flex flex-wrap items-center gap-2 text-sm">
          <select className={input + ' dark:bg-slate-900'} value={priority} onChange={(e) => setPriority(e.target.value as Priority)}>{PRIORITIES.map((p) => <option key={p}>{p}</option>)}</select>
          <label className="flex items-center gap-1">Est <input type="number" min={5} step={5} className={input + ' w-16 flex-none'} value={est} onChange={(e) => setEst(+e.target.value)} /> min</label>
          {s.role === 'CEO' && <label className="flex items-center gap-1"><input type="checkbox" checked={delegate} onChange={(e) => setDelegate(e.target.checked)} /> Delegate to assistant</label>}
        </div>
      </Card>
      <Card>
        <div className="mb-3 flex gap-2 text-sm">{(['open', 'done', 'all'] as const).map((f) => <button key={f} onClick={() => setFilter(f)} className={`rounded-full px-3 py-1 ${filter === f ? 'bg-emerald-500 text-white' : 'bg-slate-200 dark:bg-slate-800'}`}>{f}</button>)}</div>
        <ul className="space-y-3">
          {shown.map((t) => (
            <li key={t.id} className="flex items-center gap-3">
              <button aria-label="Toggle task" onClick={() => upd(t.id, { done: !t.done })} className={`flex h-6 w-6 shrink-0 items-center justify-center rounded-full border ${t.done ? 'border-emerald-500 bg-emerald-500 text-white' : 'border-slate-400'}`}>{t.done && <Check size={14} />}</button>
              <span className={`h-2 w-2 shrink-0 rounded-full ${DOT[t.priority]}`} />
              <div className="flex-1 text-sm">
                <div className={t.done ? 'text-slate-400 line-through' : ''}>{t.title}{t.from && <span className="ml-2 rounded bg-emerald-100 px-1.5 text-xs text-emerald-700">Delegated by {t.from}</span>}</div>
                <div className="text-xs text-slate-500">Est {t.estMin}m · Actual {t.actMin}m</div>
              </div>
              <button aria-label="Delete task" className="text-slate-400" onClick={() => set({ tasks: s.tasks.filter((x) => x.id !== t.id) })}><Trash2 size={16} /></button>
            </li>
          ))}
          {shown.length === 0 && <p className="text-sm text-slate-500">No tasks here.</p>}
        </ul>
      </Card>
    </>
  );
}

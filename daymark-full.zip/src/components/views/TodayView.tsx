import { Timer } from 'lucide-react';
import { today, useDay } from '../../context/DaymarkContext';
import { Card, btn, clock, ghost } from '../ui';

export default function TodayView() {
  const { s, timer } = useDay();
  const done = s.tasks.filter((t) => t.done).length;
  const pct = s.tasks.length ? Math.round((done / s.tasks.length) * 100) : 0;
  const habitsDone = s.habits.filter((h) => h.days.includes(today())).length;
  const focus = s.tasks.filter((t) => !t.done).slice(0, 3);
  return (
    <>
      <Card title="Today">
        <div className="flex justify-between text-sm font-semibold"><span>{done}/{s.tasks.length} tasks</span><span>{pct}%</span></div>
        <div className="mt-2 h-2 rounded-full bg-slate-200 dark:bg-slate-800"><div className="h-2 rounded-full bg-emerald-500 transition-all" style={{ width: `${pct}%` }} /></div>
        <p className="mt-3 text-sm text-slate-500">Habits: {habitsDone}/{s.habits.length} done today</p>
      </Card>
      <Card title="Timer">
        <div className="flex items-center justify-between">
          <span className="flex items-center gap-2 font-mono text-xl"><Timer size={18} />{clock(timer.secs)}</span>
          <div className="flex gap-2">
            <button className={btn} onClick={timer.toggle}>{timer.running ? 'Pause' : 'Start'}</button>
            <button className={ghost} onClick={timer.reset}>Reset</button>
          </div>
        </div>
      </Card>
      <Card title="Priority focus">
        {focus.length === 0 ? <p className="text-sm text-slate-500">Nothing open. Nice work.</p> : (
          <ul className="space-y-2 text-sm">{focus.map((t) => <li key={t.id}>{t.priority}: {t.title}{t.from && <span className="ml-2 text-xs text-emerald-600">from {t.from}</span>}</li>)}</ul>
        )}
      </Card>
    </>
  );
}

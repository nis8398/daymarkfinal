import { useState } from 'react';
import { CATEGORIES, today, useDay } from '../../context/DaymarkContext';
import { Card, btn, clock, ghost, input } from '../ui';

export default function TimeView() {
  const { s, set, timer } = useDay();
  const [label, setLabel] = useState('');
  const todays = s.entries.filter((e) => e.date === today());
  const total = todays.reduce((a, e) => a + e.mins, 0);
  return (
    <>
      <Card title="Time tracker">
        <div className="text-center font-mono text-3xl">{clock(timer.secs)}</div>
        <div className="mt-3 flex gap-2">
          <select className={input + ' dark:bg-slate-900'} value={timer.category} onChange={(e) => timer.setCategory(e.target.value)}>{CATEGORIES.map((c) => <option key={c}>{c}</option>)}</select>
          <input className={input} placeholder="What are you doing?" value={label} onChange={(e) => setLabel(e.target.value)} />
        </div>
        <div className="mt-3 flex gap-2">
          <button className={btn} onClick={timer.toggle}>{timer.running ? 'Pause' : 'Start'}</button>
          <button className={ghost} disabled={timer.secs < 1} onClick={() => { timer.save(label); setLabel(''); }}>Save entry</button>
          <button className={ghost} onClick={timer.reset}>Reset</button>
        </div>
      </Card>
      <Card title={`Today by category (${total} min)`}>
        {CATEGORIES.map((c) => { const m = todays.filter((e) => e.category === c).reduce((a, e) => a + e.mins, 0);
          return <div key={c} className="mb-2 text-sm"><div className="flex justify-between"><span>{c}</span><span>{m}m</span></div><div className="h-2 rounded-full bg-slate-200 dark:bg-slate-800"><div className="h-2 rounded-full bg-emerald-500" style={{ width: total ? `${(m / total) * 100}%` : 0 }} /></div></div>; })}
      </Card>
      <Card title="Ledger">
        <ul className="space-y-2 text-sm">
          {s.entries.slice(0, 30).map((e) => <li key={e.id} className="flex justify-between"><span>{e.date} · {e.category} · {e.label}</span><span className="flex items-center gap-2">{e.mins}m<button className="text-slate-400" aria-label="Delete entry" onClick={() => set({ entries: s.entries.filter((x) => x.id !== e.id) })}>×</button></span></li>)}
          {s.entries.length === 0 && <p className="text-slate-500">No entries yet.</p>}
        </ul>
      </Card>
    </>
  );
}

import { useState } from 'react';
import confetti from 'canvas-confetti';
import { Star } from 'lucide-react';
import { Routine, today, useDay } from '../../context/DaymarkContext';
import { Card, btn, ghost, input } from '../ui';

function Runner({ r, onClose }: { r: Routine; onClose: () => void }) {
  const { s, set } = useDay();
  const [i, setI] = useState(0);
  const last = i === r.steps.length - 1;
  const next = () => {
    if (!last) return setI(i + 1);
    if (r.habitId) set({ habits: s.habits.map((h) => h.id === r.habitId && !h.days.includes(today()) ? { ...h, days: [...h.days, today()] } : h) });
    confetti({ particleCount: 80, spread: 70 });
    onClose();
  };
  return (
    <Card title={`${r.name} · step ${i + 1}/${r.steps.length}`}>
      <p className="text-lg">{r.steps[i]}</p>
      <div className="mt-4 flex gap-2"><button className={btn} onClick={next}>{last ? 'Finish' : 'Next'}</button><button className={ghost} onClick={onClose}>Exit</button></div>
    </Card>
  );
}

export default function MoreView() {
  const { s, set } = useDay();
  const [run, setRun] = useState<Routine | null>(null);
  const existing = s.reviews.find((r) => r.date === today());
  const [energy, setEnergy] = useState(existing?.energy ?? 0);
  const [note, setNote] = useState(existing?.note ?? '');
  const saveReview = () => {
    set({ reviews: [{ date: today(), energy, note }, ...s.reviews.filter((r) => r.date !== today())] });
    confetti({ particleCount: 60, spread: 60 });
  };
  const doneTasks = s.tasks.filter((t) => t.done).length;
  const canEdit = (field: 'briefing' | 'report') => (field === 'briefing') === (s.role === 'CEO');
  return (
    <>
      <Card title="Role and delegation">
        <div className="mb-3 flex gap-2">{(['CEO', 'Assistant'] as const).map((r) => <button key={r} onClick={() => set({ role: r })} className={`flex-1 rounded-xl py-2 text-sm font-semibold ${s.role === r ? 'bg-emerald-500 text-white' : 'bg-slate-200 dark:bg-slate-800'}`}>{r}</button>)}</div>
        {(['briefing', 'report'] as const).map((f) => (
          <label key={f} className="mb-2 block text-sm"><span className="font-medium">{f === 'briefing' ? 'CEO briefing to assistant' : 'Assistant report to CEO'}</span>
            <textarea rows={3} disabled={!canEdit(f)} className={input + ' mt-1 w-full disabled:opacity-60'} value={s[f]} onChange={(e) => set({ [f]: e.target.value } as never)} placeholder={canEdit(f) ? 'Write here. It syncs across open tabs.' : `Read-only in ${s.role} mode`} /></label>
        ))}
        <p className="text-xs text-slate-500">Delegated tasks: {s.tasks.filter((t) => t.from).length}. CEO can delegate from the Tasks tab.</p>
      </Card>
      {run ? <Runner r={run} onClose={() => setRun(null)} /> : (
        <Card title="Routines"><ul className="space-y-2">{s.routines.map((r) => <li key={r.id} className="flex items-center justify-between text-sm"><span>{r.name} · {r.steps.length} steps</span><button className={btn} onClick={() => setRun(r)}>Run</button></li>)}</ul></Card>
      )}
      <Card title="End-of-day review">
        <p className="text-sm text-slate-500">{doneTasks}/{s.tasks.length} tasks done today</p>
        <div className="my-2 flex gap-1">{[1, 2, 3, 4, 5].map((n) => <button key={n} aria-label={`${n} stars`} onClick={() => setEnergy(n)}><Star size={26} className={n <= energy ? 'fill-amber-400 text-amber-400' : 'text-slate-400'} /></button>)}</div>
        <textarea rows={3} className={input + ' w-full'} placeholder="Wins, lessons, tomorrow's focus" value={note} onChange={(e) => setNote(e.target.value)} />
        <button className={btn + ' mt-2'} disabled={!energy} onClick={saveReview}>{existing ? 'Update review' : 'Save review'}</button>
      </Card>
      <Card title="Data">
        <div className="flex gap-2">
          <button className={ghost} onClick={() => { const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([JSON.stringify(s, null, 2)], { type: 'application/json' })); a.download = 'daymark-backup.json'; a.click(); }}>Export backup</button>
          <button className={ghost} onClick={() => { if (confirm('Erase all Daymark data?')) { localStorage.removeItem('daymark:v2'); location.reload(); } }}>Reset all</button>
        </div>
      </Card>
    </>
  );
}

import { useState } from 'react';
import { Flame, Plus } from 'lucide-react';
import { Habit, today, uid, useDay } from '../../context/DaymarkContext';
import { Card, btn, input } from '../ui';

const iso = (d: Date) => d.toISOString().slice(0, 10);
export function streak(h: Habit) {
  let n = 0; const d = new Date();
  for (let i = 0; i < 400; i++, d.setDate(d.getDate() - 1)) {
    const k = iso(d);
    if (h.days.includes(k)) n++;
    else if (!h.rest.includes(k) && !(i === 0)) break;
  }
  return n;
}

export default function HabitsView() {
  const { s, set } = useDay();
  const [name, setName] = useState('');
  const last7 = Array.from({ length: 7 }, (_, i) => { const d = new Date(); d.setDate(d.getDate() - (6 - i)); return d; });
  const flip = (list: string[], k: string) => list.includes(k) ? list.filter((x) => x !== k) : [...list, k];
  const upd = (id: string, f: (h: Habit) => Habit) => set({ habits: s.habits.map((h) => h.id === id ? f(h) : h) });
  return (
    <>
      <Card title="7-day consistency">
        <ul className="space-y-4">
          {s.habits.map((h) => (
            <li key={h.id}>
              <div className="mb-1 flex items-center justify-between text-sm"><span className="font-medium">{h.name}</span><span className="flex items-center gap-1 text-orange-500"><Flame size={14} />{streak(h)}</span></div>
              <div className="flex gap-1.5">
                {last7.map((d) => { const k = iso(d); const on = h.days.includes(k); const rest = h.rest.includes(k);
                  return <button key={k} aria-label={k} onClick={() => upd(h.id, (x) => ({ ...x, days: flip(x.days, k) }))} className={`h-8 flex-1 rounded-lg text-xs ${on ? 'bg-emerald-500 text-white' : rest ? 'bg-sky-200 text-sky-800' : 'bg-slate-200 dark:bg-slate-800'}`}>{'SMTWTFS'[d.getDay()]}</button>; })}
              </div>
              <button className="mt-1 text-xs text-sky-600" onClick={() => upd(h.id, (x) => ({ ...x, rest: flip(x.rest, today()) }))}>{h.rest.includes(today()) ? 'Cancel rest day' : 'Use rest day (streak freeze)'}</button>
            </li>
          ))}
        </ul>
      </Card>
      <Card title="New habit">
        <div className="flex gap-2"><input className={input} placeholder="Habit name" value={name} onChange={(e) => setName(e.target.value)} />
          <button aria-label="Add habit" className={btn} onClick={() => { if (name.trim()) { set({ habits: [...s.habits, { id: uid(), name: name.trim(), days: [], rest: [] }] }); setName(''); } }}><Plus size={18} /></button></div>
      </Card>
    </>
  );
}

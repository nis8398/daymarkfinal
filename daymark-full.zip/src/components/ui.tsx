import { ReactNode } from 'react';
export const card = 'rounded-2xl bg-white dark:bg-slate-900 shadow-sm p-4';
export const input = 'flex-1 rounded-xl border border-slate-300 dark:border-slate-700 bg-transparent px-3 py-2 text-sm';
export const btn = 'rounded-xl bg-emerald-500 px-3 py-2 text-sm font-semibold text-white disabled:opacity-40';
export const ghost = 'rounded-xl border border-slate-300 dark:border-slate-700 px-3 py-2 text-sm';
export const Card = ({ title, children }: { title?: string; children: ReactNode }) => (
  <section className={card}>{title && <h2 className="mb-3 font-bold">{title}</h2>}{children}</section>
);
export const clock = (secs: number) => [Math.floor(secs / 3600), Math.floor(secs / 60) % 60, secs % 60].map((n) => String(n).padStart(2, '0')).join(':');

import { useState } from 'react';
import { CalendarCheck, CheckSquare, Clock, Flame, Menu, Moon, Sun } from 'lucide-react';
import { DaymarkProvider, useDay } from './context/DaymarkContext';
import TodayView from './components/views/TodayView';
import TasksView from './components/views/TasksView';
import HabitsView from './components/views/HabitsView';
import TimeView from './components/views/TimeView';
import MoreView from './components/views/MoreView';

const TABS = [
  { id: 'today', label: 'Today', Icon: CalendarCheck, View: TodayView },
  { id: 'tasks', label: 'Tasks', Icon: CheckSquare, View: TasksView },
  { id: 'habits', label: 'Habits', Icon: Flame, View: HabitsView },
  { id: 'time', label: 'Time', Icon: Clock, View: TimeView },
  { id: 'more', label: 'More', Icon: Menu, View: MoreView },
] as const;

function Shell() {
  const { s, set, timer } = useDay();
  const [tab, setTab] = useState<(typeof TABS)[number]['id']>('today');
  const View = TABS.find((t) => t.id === tab)!.View;
  return (
    <div className="min-h-screen bg-slate-100 pb-24 text-slate-800 dark:bg-slate-950 dark:text-slate-100">
      <main className="mx-auto max-w-md space-y-4 p-4">
        <header className="flex items-center justify-between">
          <div><h1 className="text-2xl font-extrabold">Daymark</h1><p className="text-xs text-slate-500">{s.role} mode</p></div>
          <button aria-label="Toggle theme" className="rounded-full bg-white p-2 dark:bg-slate-900" onClick={() => set({ dark: !s.dark })}>{s.dark ? <Sun size={18} /> : <Moon size={18} />}</button>
        </header>
        {timer.running && <div className="rounded-full bg-emerald-500 px-4 py-1 text-center text-sm font-semibold text-white">Timer running · {Math.floor(timer.secs / 60)}m {timer.secs % 60}s</div>}
        <View />
      </main>
      <nav className="fixed inset-x-0 bottom-0 border-t border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900">
        <div className="mx-auto flex max-w-md">
          {TABS.map(({ id, label, Icon }) => (
            <button key={id} onClick={() => setTab(id)} className={`flex flex-1 flex-col items-center gap-0.5 py-2 text-xs ${tab === id ? 'text-emerald-500' : 'text-slate-500'}`}><Icon size={20} />{label}</button>
          ))}
        </div>
      </nav>
    </div>
  );
}

export default function App() {
  return <DaymarkProvider><Shell /></DaymarkProvider>;
}

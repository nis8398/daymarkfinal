import { createContext, ReactNode, useContext, useEffect, useState } from 'react';

export type Priority = 'Urgent' | 'High' | 'Medium' | 'Low';
export type Role = 'CEO' | 'Assistant';
export interface Task { id: string; title: string; priority: Priority; done: boolean; estMin: number; actMin: number; from?: Role; note?: string }
export interface Habit { id: string; name: string; days: string[]; rest: string[] }
export interface Routine { id: string; name: string; steps: string[]; habitId?: string }
export interface Entry { id: string; date: string; category: string; mins: number; label: string }
export interface Review { date: string; energy: number; note: string }
export interface State { tasks: Task[]; habits: Habit[]; routines: Routine[]; entries: Entry[]; reviews: Review[]; role: Role; dark: boolean; briefing: string; report: string }

export const PRIORITIES: Priority[] = ['Urgent', 'High', 'Medium', 'Low'];
export const CATEGORIES = ['Deep Work', 'Meetings', 'Admin', 'Learning', 'Personal'];
export const today = () => new Date().toISOString().slice(0, 10);
export const uid = () => Math.random().toString(36).slice(2, 9);

const KEY = 'daymark:v2';
const hid = uid();
const seed: State = {
  role: 'CEO', dark: false, briefing: '', report: '', entries: [], reviews: [],
  tasks: [{ id: uid(), title: 'Plan the day', priority: 'High', done: false, estMin: 15, actMin: 0 }],
  habits: [{ id: hid, name: 'Morning routine', days: [], rest: [] }],
  routines: [
    { id: uid(), name: 'Morning', steps: ['Water and stretch', 'Review today\'s priorities', 'Clear inbox'], habitId: hid },
    { id: uid(), name: 'Deep Work', steps: ['Silence notifications', 'Set one goal', 'Work 50 minutes'] },
    { id: uid(), name: 'Evening', steps: ['Review the day', 'Plan tomorrow', 'Shut down'] },
  ],
};

function load(): State {
  try {
    const raw = localStorage.getItem(KEY);
    return raw ? { ...seed, ...JSON.parse(raw) } : seed;
  } catch { return seed; }
}

interface Timer { secs: number; running: boolean; category: string; setCategory: (c: string) => void; toggle: () => void; reset: () => void; save: (label: string) => void }
interface Ctx { s: State; set: (patch: Partial<State>) => void; timer: Timer }
const C = createContext<Ctx | null>(null);
export const useDay = () => useContext(C)!;

export function DaymarkProvider({ children }: { children: ReactNode }) {
  const [s, setS] = useState<State>(load);
  const [secs, setSecs] = useState(0);
  const [running, setRunning] = useState(false);
  const [category, setCategory] = useState(CATEGORIES[0]);

  useEffect(() => {
    try { localStorage.setItem(KEY, JSON.stringify(s)); } catch { /* storage unavailable */ }
    document.documentElement.classList.toggle('dark', s.dark);
  }, [s]);

  useEffect(() => {
    const onStorage = (e: StorageEvent) => { if (e.key === KEY && e.newValue) setS({ ...seed, ...JSON.parse(e.newValue) }); };
    window.addEventListener('storage', onStorage);
    return () => window.removeEventListener('storage', onStorage);
  }, []);

  useEffect(() => {
    if (!running) return;
    const t = setInterval(() => setSecs((v) => v + 1), 1000);
    return () => clearInterval(t);
  }, [running]);

  const set = (patch: Partial<State>) => setS((prev) => ({ ...prev, ...patch }));
  const timer: Timer = {
    secs, running, category, setCategory,
    toggle: () => setRunning((r) => !r),
    reset: () => { setRunning(false); setSecs(0); },
    save: (label) => {
      if (secs < 1) return;
      const e: Entry = { id: uid(), date: today(), category, mins: Math.max(1, Math.round(secs / 60)), label: label || category };
      setS((prev) => ({ ...prev, entries: [e, ...prev.entries] }));
      setRunning(false); setSecs(0);
    },
  };
  return <C.Provider value={{ s, set, timer }}>{children}</C.Provider>;
}
